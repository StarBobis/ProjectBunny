# DX11 MCP 工具与调用顺序

桥的 `tools/list` 是当前接口的权威来源。用 `python $dx list --tool dx11_capture` 查看单个 schema。下表覆盖本机已验证的 21 个工具。

## 跨电脑安装与连接

完整解压项目提供的技能 ZIP。包内的 `scripts/dx11.py` 自动调用同一技能目录下附带的桥和监控模块。目标程序需要加载兼容的 ProjectBunny DX11 MCP DLL。原生游戏的 Live 工具还依赖 `mcp_enabled=1` 和推进中的 Present。

需要注册 MCP 服务时，在客户端配置中填实际解压路径。

~~~json
{
  "mcpServers": {
    "projectbunny-dx11": {
      "command": "python",
      "args": ["C:/path/to/projectbunny-dx11-mcp/scripts/dx11.py", "stdio"]
    }
  }
}
~~~

可以在任意目录调用 `python <技能目录>/scripts/dx11.py call dx11_discover`。技能默认把导出的定点缓冲区和 DXBC 放到 `%LOCALAPPDATA%/ProjectBunny/mcp-captures`，可用 `--output-dir` 指定路径。原生 F8 输出位置由目标 DLL 决定。

## 找到目标

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_discover` | 无参数，返回有渲染控制管道的 `pids`，以及带 PID、可执行文件名和可用 `target_id` 的 `targets`。 |
| `dx11_status` | 可带 `pid` 或 `target_id`，读 DLL 版本、功能标记 `features`、帧号、Hunting 模式、区域哈希开关、原生 F8 活动状态与输出目录。 |

以下 Live 工具同样支持 `pid` 或 `target_id`。有多个端点时先从发现结果选实例，将完整 `target_id` 传给后续每次调用。该标识包含 PID 和创建时间，可区分同名程序和重启前后的实例。目标重启或标识过期时重新发现。Live 结果回传 `pid` 和 `target_id`，抓取 ID 与性能快照 ID 需要在原目标上继续读取。

同一桥的不同目标可并行执行，同一目标的请求按顺序处理。给 MCP 客户端注册 `stdio` 入口即可使用并行请求。Live 超时后先查对应目标状态。按键发出后可能已执行，避免盲目重放。

## 快捷键、狩猎和性能

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_hotkeys` | 用 `offset` 枚举 action ID 和配置按键，每页最多 48 项。 |
| `dx11_hotkey` | `action` 为 action ID 或支持的别名。`phase` 为 `tap`、`press` 或 `release`，默认 `tap`。 |
| `dx11_hunting` | `kind` 为 `ib`、`vb`、`vs`、`hs`、`ds`、`gs`、`ps`、`cs` 或 `rt`。读 selected 和 visited，对 hash 列表可用 `offset` 分页。RT 返回选中 hash（可获得时）、位置和总数。 |
| `dx11_profiling` | 读取当前 CPU 性能面板的 `mode`、`frozen` 和 `text`。可用 `length`、`offset`、`snapshot_id` 分块读取。 |

- `f10` 调用配置与 ShaderFixes 重载。用 `Hunting.reload_config` 可单独重载配置。`ctrl+alt+f10` 会清除持久设置后重载，调用需显式 `confirm_wipe:true`。
- `f8` 调用原生 Frame Analysis。Hunting 需处于启用态。若 `analyse_options` 带 hold，分别发送 `press` 和 `release`。
- `ctrl+f9` 循环性能面板模式。只需读现有面板时直接用 `dx11_profiling`。CPU 的 draw 和命令列表耗时可能嵌套，汇报时分别保留。
- 用 `Hunting.toggle_hunting` 切换 Hunting，用 `Hunting.next_indexbuffer` 等 action 查找。先以 `dx11_hotkeys` 枚举实际可用的 next、previous、mark、done 和 slot 操作。模组的 action ID 例如 `KeyExample.key` 或 `KeyExample.back`，以返回值为准。
- `marking_mode=skip` 时，选中的 draw 可能被 Hunting 跳过。若按已选 hash 定点抓取无命中，可先记录 hash，再在当前操作允许的情况下取消选择或切换 Hunting，重新发起捕获。

### 完整读取 Ctrl+F9 大面板

新版 DLL 在 `dx11_status.features` 中返回 `profiling_chunks`。先读当前 `mode`，需要切换时用 `dx11_hotkey` 的 `ctrl+f9`，确认标题已经是需要的 CPU Summary、Top Command Lists 或 Top Commands。

1. 调用 `dx11_profiling`，传 `{"length":8192}` 建立快照，并记录 `snapshot_id`、`total_bytes` 和第一块 `text`。单块 `length` 支持 4–24576 字节。
2. 下一次传相同 `snapshot_id`、上一块实际返回的 `next_offset` 作为 `offset`，以及所需的 `length`。快照保持当时的模式和文本，即使游戏面板继续刷新。
3. 顺序拼接各块 `text`，原样保留换行，直到 `next_offset == total_bytes`。以 UTF-8 保存时核对编码后的字节数等于 `total_bytes`。块在字符边界结束，实际长度可能小于请求值。

直接调用 `dx11_profiling {}` 也能读取完整面板，由桥在内部拼接。大结果适合显式分块。当前 DLL 保留一个性能快照，另一次省略 `snapshot_id` 的查询会替换它。遇到 `PROFILE_SNAPSHOT_EXPIRED` 时，重新建快照并从第一块开始。遇到 `PROFILE_RANGE_INVALID` 时，先核对偏移是否沿用 `next_offset`。

## 定点捕获

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_capture` | 按条件武装下一次抓取，返回 `id` 和初始状态。 |
| `dx11_capture_status` | 输入 `capture_id`，读 `state`、`bytes`、`capture` 元数据和可用的 `fallback`。 |
| `dx11_capture_cancel` | 输入 `capture_id`，取消还在等待匹配的抓取。 |
| `dx11_capture_bytes` | 输入 `capture_id`、可选字节 `offset`、`length`，返回 `bytes_base64`、`next_offset` 和 `total_bytes`。单块上限 24 KiB。 |
| `dx11_capture_save` | 输入 `capture_id`，把有字节的结果保存成 `.bin` 或 `.dxbc`，返回 `path`。技能入口默认写入当前 Windows 用户的本地应用数据目录。 |

抓取所用的选择器

- `kind` 是必填项，可用 `draw`、`ib`、`vb`、`cb`、`srv`、`uav`、`so`、`indirect`。`draw` 返回参数、shader、布局和绑定元数据，用于确认目标后另发字节抓取。
- `hash` 传 32 位十六进制字符串，接受 `0x` 前缀。`hash_mode` 为 `auto`、`resource` 或 `region`。资源 hash 是 Hunting 使用的标识，动态资源的字节可以变化。区域 hash 要核对实际区域、绑定格式、偏移和匹配时点。
- 可用 `draw`、`stage`、`slot`、抓取元数据中的 `resource_id` 或 `source: "mod" | "game" | "any"` 避免同一 hash 的歧义。`draw` 是搜索帧里的 draw、dispatch 或注入绘制编号。`resource_id` 只在当前进程里使用。
- `phase` 为 `auto`、`before` 或 `after`。默认在调用前读输入，在调用后读 UAV 和 stream output。`offset` 和 `length` 是相对于底层 buffer 的字节，`length:0` 意味着读到末尾，单次最多 64 MiB。用小范围减少 GPU 同步等待。
- `frames` 是发起 context 的 Present 搜索上限，允许 1–120，默认 30。其他 context 的 Present 可以响应查询，待处理抓取仍等待发起 context 的绘制。结果为 `pending` 时轮询，为 `ready` 时读取或保存。原 context 停滞时可主动取消，原 context 销毁会返回 `device_changed`，此时在新 context 重新定位。按返回的 `fallback` 或目标类型决定是否走 F8。

示例参数

~~~json
{"kind":"ib","hash":"92cb56c9","hash_mode":"resource","frames":30}
~~~

~~~json
{"kind":"uav","source":"mod","stage":"cs","slot":0,"phase":"after","offset":0,"length":256}
~~~

抓取后用实际返回的 `id`，例如 `{"capture_id":42}`。分块读取从 `offset:0` 开始，逐次用 `next_offset`，直至 `total_bytes`。文件级分析优先用 `dx11_capture_save`，避免将大量 base64 放进对话。渲染捕获只保留一个结果。新抓取、读取自定义 buffer 或准备 shader 都可能替换它。

### 只抓 DrawIndexed 使用的 IB 范围

新版 DLL 在 `features` 中返回 `indexed_range`。先从 Hunting 取目标 hash。若 `marking_mode=skip` 跳过目标 draw，先记录 hash，再取消选择以便它继续绘制。

~~~json
{"kind":"ib","hash":"0e58ceb3","hash_mode":"resource","indexed_range":true,"frames":40}
~~~

`indexed_range:true` 匹配直接 `DrawIndexed` 或 `DrawIndexedInstanced`。省略手工的 `offset` 和 `length`，混用会返回 `INDEXED_RANGE_INVALID`。结果的 `capture.type` 应为 2 或 4，并包含 `index_range.offset`、`index_range.length` 和 `index_range.index_width`。字节起点为 IA 绑定偏移加起始索引乘索引宽度，长度为索引数乘宽度。

按 `capture_id` 保存结果。对比 F8 时按同一个资源 hash 找 `.buf`，在 F8 的完整 buffer 里截取 `index_range.offset` 起的 `index_range.length` 字节，再与实时文件逐字节比较。实机示例里 54 个 R16 索引是 108 字节，12 个同 hash 的 F8 文件在该范围内全部相同。若不同，查看 `buffer.usage` 并按同一 `resource_id` 和范围跨帧复读，确认字节是否变化。

## 自定义 buffer 和 shader

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_custom_buffers` | 带可选 `offset`，列出 namespaced `Resource` 节名，每页最多 48 项。 |
| `dx11_custom_buffer` | 输入列表的完整 `name`，可带 `offset` 和 `length`。已初始化的 buffer 给出可读取的捕获 ID。 |
| `dx11_shaders` | 带可选 `offset`，分页列出 shader catalog 里的 `id`、`hash`、`stage`、`name` 和字节数，每页最多 48 项。 |
| `dx11_shader` | `shader_id` 使用 catalog 的 `id`，返回新的捕获 ID。接着用 capture bytes/save 读取 DXBC。 |

先确认模组条件分支确实触发，再按 INI 中的实际 stage 和 slot 捕获。资源声明可能尚未实例化，或者当前是纹理。直接按名称读不到时，检查实际绑定，必要时等模组开始绘制后用 `source:"mod"` 定位。shader catalog 只涵盖当前保留的字节码，使用模组节名、stage 与实际 bound catalog ID 交叉确认。

### 按名读 buffer 的错误码

新版 DLL 在 `features` 中返回 `custom_resource_errors`。对 `dx11_custom_buffer` 的错误结果，优先读取 `structuredContent.code`。命令行客户端在错误文字开头显示同一个码。

| 错误码 | 含义与后续 |
| --- | --- |
| `CUSTOM_RESOURCE_NOT_FOUND` | 当前加载的配置找不到这个节名。用 `dx11_custom_buffers` 核对完整命名空间和名称。 |
| `CUSTOM_RESOURCE_UNINITIALIZED` | 声明存在，当前还没有初始化实例。检查实例化条件和初始化命令是否已执行。 |
| `CUSTOM_RESOURCE_NULL` | 现有资源当前解析为空。查给该 Resource 赋值或清空的命令和调用阶段。 |
| `CUSTOM_RESOURCE_NO_INSTANCE` | 资源没有可用的底层 D3D11 对象。结合创建日志或帧内绑定定位。 |
| `CUSTOM_RESOURCE_NOT_BUFFER` | 当前对象的 D3D11 类型不支持 buffer 读回。纹理数据用 F8。 |
| `CUSTOM_RESOURCE_WRONG_DEVICE` | 活跃 buffer 属于另一个 D3D11 设备。检查它所在的渲染路径和设备。 |

若获得了捕获 ID，读回阶段的 `mapped`、`unsupported`、`range_out_of_bounds` 等状态在捕获结果中查看。看到 `mapped` 时等目标完成 Unmap 后重试，热重载开关期间仍保留映射状态。按名读失败时也可以在实际 draw 或 dispatch 的绑定槽上定点抓取。

## 文件日志和 F8

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_log_tail` | `source:"runtime"` 或 `"f8"`，可传 `lines` 1–300。读当前磁盘日志尾部，需要 Live STATUS。 |
| `dx11_frame_analysis_files` | 读当前 F8 目录和文件列表，用 `offset` 分页，每页最多 128 项。 |
| `dx11_frame_analysis_read` | 用列表中的 `name`、字节 `offset` 和 `length` 读取文件，每块最多 24 KiB，返回 `bytes_base64`、`next_offset` 和大小。 |

先查 `capture_active` 和 `frame_analysis_dir`，确认状态后在用户授权范围内调用 F8。等该次抓取完成再列表。纹理字节、延迟上下文、完整 API 调用串根据当前 `analyse_options` 走原生 F8。需要启动停滞、进程内日志或闪退时使用下面的监控工具。

## 游戏启动前、卡住、闪退

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_monitor_start` | 在启动目标前调用。可带 `target_exe`（仅文件名）、`level`（`warning`、`info`、`debug`）和启动阶段的 `stall_ms`，默认 5000。响应同时给出 Present 阶段的 `present_stall_ms`，最低 2000 ms。 |
| `dx11_monitor_poll` | 用 `after_seq`、`wait_ms`、`limit`，可带 `pid`。返回 `events`、`sessions`、`next_seq`、`transport_dropped` 和 `history_lost`。 |
| `dx11_monitor_stop` | 停止同一个桥的采集，已收取的数据仍能在该桥中 poll。 |

~~~json
{"target_exe":"ZenlessZoneZero.exe","level":"warning","stall_ms":5000}
~~~

先看 `waiting_for_dll`。每次调用用返回的 `next_seq`，例如 `{"after_seq":0,"wait_ms":5000,"limit":128}`。监控会持续接收数据，长轮询只是拉取。默认启动阶段包含 INFO，运行期是 WARNING。排查运行时内部消息可短时设 `info`，需要高频细节时再设 `debug`。记录丢失字段并避免把无事件误当成没有发生故障。

`no_progress` 表示超过阈值未观察到阶段或帧进展，报出 `phase`、`last_frame`、`progress_age_ms`、`stall_threshold_ms` 与最后几条日志。`process_exit` 可能附 Windows 退出码，极快退出时退出码可能不可用。进程已过 DLL 加载入口后才开启时，正常 Present 可让它晚接入，早期日志无法补抓。Windows 在 DLL 加载入口执行前结束进程时，没有 DLL 内部记录。

没有常驻 MCP 工具时，用技能客户端提前开始。下面示例在确认 Present 后退出，也可用 `--until no_progress` 或 `--until exited`。用带超时的后台执行会话让工具先返回就绪事件，再让用户正常启动游戏。单次等待保持有界，监控期间持续消费输出。

~~~powershell
$dx = 'C:/path/to/projectbunny-dx11-mcp/scripts/dx11.py'
python $dx watch --exe ZenlessZoneZero.exe --until presenting --seconds 180
~~~

需要在桥退出后继续查采样时，为 `watch` 指定新的 `--record` NDJSON 文件。每个 Windows 会话同时只有一个监控桥。遇到已有所有者就复用原会话。没有权限访问原会话时，先向用户核对当前运行的桥，避免结束他已开的监控。

### 游戏继续运行时重连监控

1. 如果是在更换自己开启的 stdio 桥，结束旧桥进程以释放监控所有权。在新桥调用 `dx11_monitor_start`，继续使用同一个 `target_exe`。
2. 用新结果的 `next_seq` 开始 `dx11_monitor_poll`，可传原游戏 PID。新桥的游标属于新会话，查询该桥已收取的历史时用 `after_seq:0`。
3. 在 `sessions` 里核对 `pid` 和 `process_start`。两者与断开前相同表示同一次游戏运行。`identity_source:"process_image"` 表示通过进程信息恢复身份，`"identity"` 表示收到 DLL 周期发布的身份，`"attach"` 表示直接使用了启动记录。随后看 `state`、`phase`、`last_frame` 和进展时间。

即使初始 attach 已被覆盖，新桥也可重新关联仍在运行的游戏。重连从传输环仍保留的事件继续，用 `transport_dropped` 和 `history_lost` 判断记录完整度。

## 验证和排查入口

- 分别核对加载器磁盘上的 DLL 和进程实际接口。版本号相同仍可能是不同构建，可比较文件 SHA256，再用 Live STATUS 或 attach、Present 事件验证当前进程具备功能。
- 如果桥初始化成功、游戏进程存在而 `dx11_discover` 空，优先检查 Present、已部署的 DLL 和 `mcp_enabled`。已启动的监控可以在此时继续记录独立事件。
- 使用源码检出做开发验证时，可查看仓库的 `usage/dx11/mcp.md`，并在对应构建目录运行 `dx11_mcp_regression` 和 `dx11_mcp_monitor_regression`。
