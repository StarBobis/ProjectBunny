# DX11 MCP 工具与调用顺序

桥的 `tools/list` 是当前接口的权威来源。用 `python $dx list --tool dx11_capture` 查看单个 schema。下表覆盖本机已验证的 21 个工具。

## 跨电脑安装与连接

完整解压项目提供的技能 ZIP。包内的 `scripts/dx11.py` 自动调用同一技能目录下附带的桥和监控模块。目标程序需要加载兼容的 ProjectBunny DX11 MCP DLL。原生游戏的 Live 工具还依赖 `mcp_enabled=1` 和推进中的 Present。

需要注册 MCP 服务时，在客户端配置中填实际解压路径。

~~~json
{
  "mcpServers": {
    "projectbunny-dx11": {
      "command": "python",
      "args": ["C:/path/to/projectbunny-dx11-mcp/scripts/dx11.py", "stdio"]
    }
  }
}
~~~

可以在任意目录调用 `python <技能目录>/scripts/dx11.py call dx11_discover`。技能默认把导出的定点缓冲区和 DXBC 放到 `%LOCALAPPDATA%/ProjectBunny/mcp-captures`，可用 `--output-dir` 指定路径。原生 F8 输出位置由目标 DLL 决定。

## 找到目标

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_discover` | 无参数，返回有渲染控制管道的 `pids`，以及带 PID、可执行文件名和可用 `target_id` 的 `targets`。 |
| `dx11_status` | 可带 `pid` 或 `target_id`，读 DLL 版本、功能标记 `features`、帧号、Hunting 模式、区域哈希开关、原生 F8 活动状态与输出目录。 |

以下 Live 工具同样支持 `pid` 或 `target_id`。有多个端点时先从发现结果选实例，将完整 `target_id` 传给后续每次调用。该标识包含 PID 和创建时间，可区分同名程序和重启前后的实例。目标重启或标识过期时重新发现。Live 结果回传 `pid` 和 `target_id`，抓取 ID 与性能快照 ID 需要在原目标上继续读取。

同一桥的不同目标可并行执行，同一目标的请求按顺序处理。给 MCP 客户端注册 `stdio` 入口即可使用并行请求。Live 超时后先查对应目标状态。按键发出后可能已执行，避免盲目重放。

## 快捷键、狩猎和性能

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_hotkeys` | 用 `offset` 枚举 action ID 和配置按键，每页最多 48 项。 |
| `dx11_hotkey` | `action` 为 action ID 或支持的别名。`phase` 为 `tap`、`press` 或 `release`，默认 `tap`。 |
| `dx11_hunting` | `kind` 为 `ib`、`vb`、`vs`、`hs`、`ds`、`gs`、`ps`、`cs` 或 `rt`。读 selected 和 visited，对 hash 列表可用 `offset` 分页。RT 返回选中 hash（可获得时）、位置和总数。 |
| `dx11_profiling` | 读取当前 CPU 性能面板的 `mode`、`frozen` 和 `text`。可用 `length`、`offset`、`snapshot_id` 分块读取。 |

- `f10` 调用配置与 ShaderFixes 重载。用 `Hunting.reload_config` 可单独重载配置。`ctrl+alt+f10` 会清除持久设置后重载，调用需显式 `confirm_wipe:true`。
- `f8` 调用原生 Frame Analysis。Hunting 需处于启用态。若 `analyse_options` 带 hold，分别发送 `press` 和 `release`。
- `ctrl+f9` 循环性能面板模式。只需读现有面板时直接用 `dx11_profiling`。CPU 的 draw 和命令列表耗时可能嵌套，汇报时分别保留。
- 用 `Hunting.toggle_hunting` 切换 Hunting，用 `Hunting.next_indexbuffer` 等 action 查找。先以 `dx11_hotkeys` 枚举实际可用的 next、previous、mark、done 和 slot 操作。模组的 action ID 例如 `KeyExample.key` 或 `KeyExample.back`，以返回值为准。
- `marking_mode=skip` 时，选中的 draw 可能被 Hunting 跳过。若按已选 hash 定点抓取无命中，可先记录 hash，再在当前操作允许的情况下取消选择或切换 Hunting，重新发起捕获。

### 完整读取 Ctrl+F9 大面板

新版 DLL 在 `dx11_status.features` 中返回 `profiling_chunks`。先读当前 `mode`，需要切换时用 `dx11_hotkey` 的 `ctrl+f9`，确认标题已经是需要的 CPU Summary、Top Command Lists 或 Top Commands。

1. 调用 `dx11_profiling`，传 `{"length":8192}` 建立快照，并记录 `snapshot_id`、`total_bytes` 和第一块 `text`。单块 `length` 支持 4–24576 字节。
2. 下一次传相同 `snapshot_id`、上一块实际返回的 `next_offset` 作为 `offset`，以及所需的 `length`。快照保持当时的模式和文本，即使游戏面板继续刷新。
3. 顺序拼接各块 `text`，原样保留换行，直到 `next_offset == total_bytes`。以 UTF-8 保存时核对编码后的字节数等于 `total_bytes`。块在字符边界结束，实际长度可能小于请求值。

直接调用 `dx11_profiling {}` 也能读取完整面板，由桥在内部拼接。大结果适合显式分块。当前 DLL 保留一个性能快照，另一次省略 `snapshot_id` 的查询会替换它。遇到 `PROFILE_SNAPSHOT_EXPIRED` 时，重新建快照并从第一块开始。遇到 `PROFILE_RANGE_INVALID` 时，先核对偏移是否沿用 `next_offset`。

## 定点读取原始贴图的 dHash

调用 `dx11_texture_dhash`，传 `ib_hash`、`index_count`、`first_index` 和 `slots`。可选 `ps_hash` 用来区分同一 IB 的材质、阴影等 pass。区域哈希还要传 `hash_mode: "region"` 和底层 IB 的 `resource_hash`。普通 IB 哈希用默认的 `hash_mode: "resource"`。

~~~json
{"ib_hash":"1234abcd","hash_mode":"region","resource_hash":"abcd1234","index_count":600,"first_index":0,"ps_hash":"0123456789abcdef","slots":[16,17,18]}
~~~

`ps_hash` 按实际绑定的像素着色器校验。实时 dHash 读取采用最新已跟踪的纹理版本，模组匹配继续遵循自身的缓存策略。

用相同目标的 `dx11_capture_status` 读取返回的捕获 ID。`capture.slots` 给出 INI 覆盖执行前的原始 PS 槽位、格式和 64 位 `dhash`。空槽报告 `unbound`，无法计算的纹理报告 `unavailable`。一次请求可指定 1 到 8 个不同槽位。查看 `dx11_status.features` 确认 DLL 提供 `texture_dhash`。

## 定点捕获

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_capture` | 按条件武装下一次抓取，返回 `id` 和初始状态。 |
| `dx11_capture_status` | 输入 `capture_id`，读 `state`、`bytes`、`capture` 元数据和可用的 `fallback`。 |
| `dx11_capture_cancel` | 输入 `capture_id`，取消还在等待匹配的抓取。 |
| `dx11_capture_bytes` | 输入 `capture_id`、可选字节 `offset`、`length`，返回 `bytes_base64`、`next_offset` 和 `total_bytes`。单块上限 24 KiB。 |
| `dx11_capture_save` | 输入 `capture_id`，把有字节的结果保存成 `.bin` 或 `.dxbc`，返回 `path`。技能入口默认写入当前 Windows 用户的本地应用数据目录。 |

抓取所用的选择器

- `kind` 是必填项，可用 `draw`、`ib`、`vb`、`cb`、`srv`、`uav`、`so`、`indirect`。`draw` 返回参数、shader、布局和绑定元数据，用于确认目标后另发字节抓取。
- `hash` 传 32 位十六进制字符串，接受 `0x` 前缀。`hash_mode` 为 `auto`、`resource` 或 `region`。资源 hash 是 Hunting 使用的标识，动态资源的字节可以变化。区域 hash 要核对实际区域、绑定格式、偏移和匹配时点。
- 可用 `draw`、`stage`、`slot`、抓取元数据中的 `resource_id` 或 `source: "mod" | "game" | "any"` 避免同一 hash 的歧义。`draw` 是搜索帧里的 draw、dispatch 或注入绘制编号。`resource_id` 只在当前进程里使用。
- `phase` 为 `auto`、`before` 或 `after`。默认在调用前读输入，在调用后读 UAV 和 stream output。`offset` 和 `length` 是相对于底层 buffer 的字节，`length:0` 意味着读到末尾，单次最多 64 MiB。用小范围减少 GPU 同步等待。
- `frames` 是发起 context 的 Present 搜索上限，允许 1–120，默认 30。其他 context 的 Present 可以响应查询，待处理抓取仍等待发起 context 的绘制。结果为 `pending` 时轮询，为 `ready` 时读取或保存。原 context 停滞时可主动取消，原 context 销毁会返回 `device_changed`，此时在新 context 重新定位。按返回的 `fallback` 或目标类型决定是否走 F8。

示例参数

~~~json
{"kind":"ib","hash":"92cb56c9","hash_mode":"resource","frames":30}
~~~

~~~json
{"kind":"uav","source":"mod","stage":"cs","slot":0,"phase":"after","offset":0,"length":256}
~~~

抓取后用实际返回的 `id`，例如 `{"capture_id":42}`。分块读取从 `offset:0` 开始，逐次用 `next_offset`，直至 `total_bytes`。文件级分析优先用 `dx11_capture_save`，避免将大量 base64 放进对话。渲染捕获只保留一个结果。新抓取、读取自定义 buffer 或准备 shader 都可能替换它。

### 只抓 DrawIndexed 使用的 IB 范围

新版 DLL 在 `features` 中返回 `indexed_range`。先从 Hunting 取目标 hash。若 `marking_mode=skip` 跳过目标 draw，先记录 hash，再取消选择以便它继续绘制。

~~~json
{"kind":"ib","hash":"0e58ceb3","hash_mode":"resource","indexed_range":true,"frames":40}
~~~

`indexed_range:true` 匹配直接 `DrawIndexed` 或 `DrawIndexedInstanced`。省略手工的 `offset` 和 `length`，混用会返回 `INDEXED_RANGE_INVALID`。结果的 `capture.type` 应为 2 或 4，并包含 `index_range.offset`、`index_range.length` 和 `index_range.index_width`。字节起点为 IA 绑定偏移加起始索引乘索引宽度，长度为索引数乘宽度。

按 `capture_id` 保存结果。对比 F8 时按同一个资源 hash 找 `.buf`，在 F8 的完整 buffer 里截取 `index_range.offset` 起的 `index_range.length` 字节，再与实时文件逐字节比较。实机示例里 54 个 R16 索引是 108 字节，12 个同 hash 的 F8 文件在该范围内全部相同。若不同，查看 `buffer.usage` 并按同一 `resource_id` 和范围跨帧复读，确认字节是否变化。

## 自定义 buffer 和 shader

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_custom_buffers` | 带可选 `offset`，列出 namespaced `Resource` 节名，每页最多 48 项。 |
| `dx11_custom_buffer` | 输入列表的完整 `name`，可带 `offset` 和 `length`。已初始化的 buffer 给出可读取的捕获 ID。 |
| `dx11_shaders` | 带可选 `offset`，分页列出 shader catalog 里的 `id`、`hash`、`stage`、`name` 和字节数，每页最多 48 项。 |
| `dx11_shader` | `shader_id` 使用 catalog 的 `id`，返回新的捕获 ID。接着用 capture bytes/save 读取 DXBC。 |

先确认模组条件分支确实触发，再按 INI 中的实际 stage 和 slot 捕获。资源声明可能尚未实例化，或者当前是纹理。直接按名称读不到时，检查实际绑定，必要时等模组开始绘制后用 `source:"mod"` 定位。shader catalog 只涵盖当前保留的字节码，使用模组节名、stage 与实际 bound catalog ID 交叉确认。

### 按名读 buffer 的错误码

新版 DLL 在 `features` 中返回 `custom_resource_errors`。对 `dx11_custom_buffer` 的错误结果，优先读取 `structuredContent.code`。命令行客户端在错误文字开头显示同一个码。

| 错误码 | 含义与后续 |
| --- | --- |
| `CUSTOM_RESOURCE_NOT_FOUND` | 当前加载的配置找不到这个节名。用 `dx11_custom_buffers` 核对完整命名空间和名称。 |
| `CUSTOM_RESOURCE_UNINITIALIZED` | 声明存在，当前还没有初始化实例。检查实例化条件和初始化命令是否已执行。 |
| `CUSTOM_RESOURCE_NULL` | 现有资源当前解析为空。查给该 Resource 赋值或清空的命令和调用阶段。 |
| `CUSTOM_RESOURCE_NO_INSTANCE` | 资源没有可用的底层 D3D11 对象。结合创建日志或帧内绑定定位。 |
| `CUSTOM_RESOURCE_NOT_BUFFER` | 当前对象的 D3D11 类型不支持 buffer 读回。纹理数据用 F8。 |
| `CUSTOM_RESOURCE_WRONG_DEVICE` | 活跃 buffer 属于另一个 D3D11 设备。检查它所在的渲染路径和设备。 |

若获得了捕获 ID，读回阶段的 `mapped`、`unsupported`、`range_out_of_bounds` 等状态在捕获结果中查看。看到 `mapped` 时等目标完成 Unmap 后重试，热重载开关期间仍保留映射状态。按名读失败时也可以在实际 draw 或 dispatch 的绑定槽上定点抓取。

## 文件日志和 F8

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_log_tail` | `source:"runtime"` 或 `"f8"`，可传 `lines` 1–300。读当前磁盘日志尾部，需要 Live STATUS。 |
| `dx11_frame_analysis_files` | 读当前 F8 目录和文件列表，用 `offset` 分页，每页最多 128 项。 |
| `dx11_frame_analysis_read` | 用列表中的 `name`、字节 `offset` 和 `length` 读取文件，每块最多 24 KiB，返回 `bytes_base64`、`next_offset` 和大小。 |

先查 `capture_active` 和 `frame_analysis_dir`，确认状态后在用户授权范围内调用 F8。等该次抓取完成再列表。纹理字节、延迟上下文、完整 API 调用串根据当前 `analyse_options` 走原生 F8。需要启动停滞、进程内日志或闪退时使用下面的监控工具。

## 游戏启动前、卡住、闪退

| 工具 | 输入与读取结果 |
| --- | --- |
| `dx11_monitor_start` | 在启动目标前调用。可带 `target_exe`（仅文件名）、`level`（`warning`、`info`、`debug`）和启动阶段的 `stall_ms`，默认 5000。响应同时给出 Present 阶段的 `present_stall_ms`，最低 2000 ms。 |
| `dx11_monitor_poll` | 用 `after_seq`、`wait_ms`、`limit`，可带 `pid`。返回 `events`、`sessions`、`next_seq`、`transport_dropped` 和 `history_lost`。 |
| `dx11_monitor_stop` | 停止同一个桥的采集，已收取的数据仍能在该桥中 poll。 |

~~~json
{"target_exe":"ZenlessZoneZero.exe","level":"warning","stall_ms":5000}
~~~

先看 `waiting_for_dll`。每次调用用返回的 `next_seq`，例如 `{"after_seq":0,"wait_ms":5000,"limit":128}`。监控会持续接收数据，长轮询只是拉取。默认启动阶段包含 INFO，运行期是 WARNING。排查运行时内部消息可短时设 `info`，需要高频细节时再设 `debug`。记录丢失字段并避免把无事件误当成没有发生故障。

`no_progress` 表示超过阈值未观察到阶段或帧进展，报出 `phase`、`last_frame`、`progress_age_ms`、`stall_threshold_ms` 与最后几条日志。`process_exit` 可能附 Windows 退出码，极快退出时退出码可能不可用。进程已过 DLL 加载入口后才开启时，正常 Present 可让它晚接入，早期日志无法补抓。Windows 在 DLL 加载入口执行前结束进程时，没有 DLL 内部记录。

没有常驻 MCP 工具时，用技能客户端提前开始。下面示例在确认 Present 后退出，也可用 `--until no_progress` 或 `--until exited`。用带超时的后台执行会话让工具先返回就绪事件，再让用户正常启动游戏。单次等待保持有界，监控期间持续消费输出。

~~~powershell
$dx = 'C:/path/to/projectbunny-dx11-mcp/scripts/dx11.py'
python $dx watch --exe ZenlessZoneZero.exe --until presenting --seconds 180
~~~

需要在桥退出后继续查采样时，为 `watch` 指定新的 `--record` NDJSON 文件。每个 Windows 会话同时只有一个监控桥。遇到已有所有者就复用原会话。没有权限访问原会话时，先向用户核对当前运行的桥，避免结束他已开的监控。

### 游戏继续运行时重连监控

1. 如果是在更换自己开启的 stdio 桥，结束旧桥进程以释放监控所有权。在新桥调用 `dx11_monitor_start`，继续使用同一个 `target_exe`。
2. 用新结果的 `next_seq` 开始 `dx11_monitor_poll`，可传原游戏 PID。新桥的游标属于新会话，查询该桥已收取的历史时用 `after_seq:0`。
3. 在 `sessions` 里核对 `pid` 和 `process_start`。两者与断开前相同表示同一次游戏运行。`identity_source:"process_image"` 表示通过进程信息恢复身份，`"identity"` 表示收到 DLL 周期发布的身份，`"attach"` 表示直接使用了启动记录。随后看 `state`、`phase`、`last_frame` 和进展时间。

即使初始 attach 已被覆盖，新桥也可重新关联仍在运行的游戏。重连从传输环仍保留的事件继续，用 `transport_dropped` 和 `history_lost` 判断记录完整度。

## 验证和排查入口

- 分别核对加载器磁盘上的 DLL 和进程实际接口。版本号相同仍可能是不同构建，可比较文件 SHA256，再用 Live STATUS 或 attach、Present 事件验证当前进程具备功能。
- 如果桥初始化成功、游戏进程存在而 `dx11_discover` 空，优先检查 Present、已部署的 DLL 和 `mcp_enabled`。已启动的监控可以在此时继续记录独立事件。
- 使用源码检出做开发验证时，可查看仓库的 `usage/dx11/mcp.md`，并在对应构建目录运行 `dx11_mcp_regression` 和 `dx11_mcp_monitor_regression`。

## 回溯蒙皮缓冲区的 CPU 上传

支持的 DLL 在 `dx11_status.features` 中公布 `resource_provenance`。用 `dx11_resource_trace` 为当前设备开启短时间观测，再用同一目标和 `trace_id` 读取结果。选择原始 IB 资源哈希时，可附带 `first_index` 和 `index_count` 区分共用 IB 的部件。也可以使用 `uav_hash`、`cs_hash` 或同一进程的 `resource_id`。后面三项同时提供时需要同时命中。角色、场景和部件均由实际绑定决定。

~~~json
{"ib_hash":"4e993b0e","first_index":0,"index_count":37203,"frames":2}
~~~

1. 用 `dx11_resource_trace_status` 等待 `ready`。遇到 `no_match` 时查看 `miss_reason`、`indexed_draws`、`dispatches`、`dropped` 和 `command_list_gaps`。也可用 `dx11_resource_trace_cancel` 提前结束并读取已经收集的证据。
2. 用 `dx11_resource_trace_list` 列出命中项，用 `next_offset` 分页。同哈希资源通过底层 `resource_id` 区分。
3. 将命中项的 `submission` 传给 `dx11_resource_trace_chain`。IB 锚点从 DrawIndexed 的 VB0 往前追经过的 Copy、CS 输出 UAV 和 CS-t0/t1/t2。CS 或 UAV 锚点列出输入来源和后续能关联的 VB0 消费者。
4. 用 `dx11_resource_trace_event` 读取链中某个 `submission` 的完整字段。每个事件包含资源实例、描述符、区间、录制和提交的帧与 context，以及 CPU 源字节的 CRC32C 和长度。调用栈能解析时，还会给出首个 DLL 外的调用方模块和偏移。

`record` 与 `record_qpc` 指向录制位置，`submission` 按所观察的即时 context API 提交排列。延迟列表的 `command_list_id` 在重复执行时相同，`execute_id` 随每次执行变化，`list_order` 保留列表内相对次序。`submit_qpc` 标记提交时间。延迟列表在执行前仅保留参数和取证数据。延迟绑定随 setter 记录，由 `binding_source: "deferred_setters"` 标识。列表在采集开始前已有命令、绕开包装层，或追踪丢失时会留下缺口。序号用于比较记录到的 CPU 提交，GPU 完成时间需另行测量。

CreateBuffer 初始数据的哈希在启用 MCP 后随资源保存，后续绑定可以读到它。追到窗口以前的初始数据时，状态为 `initial_data_before_observation_window`。UpdateSubresource/1 和区域 Copy 返回观察到的区间。Unmap 的 `cpu_source_bytes` 是结束映射前的快照长度，`map_record`、`map_frame`、`map_thread` 和 `map_qpc` 指向对应 Map。D3D11 不提供 Map 的实际脏字节范围，`destination_range` 此时为空。CS UAV 和 VB0 分别给出 view 窗口和可用缓冲区窗口，具体读写字节由 shader 和索引决定。直接索引绘制的 IB 区间按绑定偏移和索引格式计算。

默认仅保存元数据和哈希。需要原始字节时，在首次查询得到目标输入的 `resource_id` 后重新布置采集，同时传入 `sample_resource_id` 和 `sample_bytes`。例如下面的请求保存实例 42 每次更新的前 12 KiB。

~~~json
{"resource_id":42,"sample_resource_id":42,"sample_bytes":12288,"frames":2}
~~~

用 `dx11_resource_trace_bytes` 读取某条更新的 Base64 数据。匹配实例才保存字节。每次观测最多保留 8192 条提交和 4 MiB 样本。CPU 哈希预算为每个事件 16 MiB、每次观测 128 MiB，超限原因分别在 `cpu_source_state` 和 `sample_state` 中报告。`dx11_resource_trace_chain` 的 `truncated` 标记受事件或链路上限影响的结果。新观测会替换已结束的结果。

APMI 可对角色详情、大世界、编组逐一复用这一路径。上述选择器取自编组页的 F8 样例。该样例的第 57 行上传到随后在第 72 行绑定为 CS-t2 的实例。第 74 行的 UAV 实例在第 2863 行用作 VB0，第 2868 行绑定 IB `4e993b0e`，第 2891 行绘制 37203 个索引。选择器使用实际 `IASetIndexBuffer` 资源哈希。

已有 F8 样例中，三个场景各有 6 条 CS-t2 绑定可按同一资源地址定位到更早的 CPU 上传。对同帧唯一且非零的矩阵比较得到的 177 槽对应和头发槽锚点适合做验收。需要补抓时可结合 Frame Analysis 的 `dump_on_update`，用已知 IB 范围、CS、槽位和底层实例对齐两份证据。家园或新角色首次观测时可先用 CS 或输出 UAV 发现各自的 IB 和输入实例。

#### 深挖选定上传的调用栈

`dx11_status.features` 包含 `resource_caller_frames` 时，可在 `dx11_resource_trace` 传入 `caller_frames`。先从目标链的 CPU 上传事件取得目的 `resource_id`，再将它作为 `caller_resource_id` 重新观测。以资源 ID 为主选择器时，`caller_resource_id` 默认等于 `resource_id`。资源实例 ID 只在同一目标进程内有效。下面的例子仅适用于先前已识别实例 67 的目标。

~~~json
{"ib_hash":"41e0edb1","first_index":0,"index_count":30666,"frames":2,"caller_resource_id":67,"caller_frames":24}
~~~

`dx11_resource_trace_event` 返回按录制线程调用顺序排列的 `caller_frames`。每帧包含 `stack_index`、模块和返回地址 RVA，可能包括 `UnityPlayer.dll` 和 `GameAssembly.dll`。原有的 `caller_module`、`caller_offset` 继续提供首个可解析的外部帧。

默认 `caller_frames=0`。开启后每条匹配上传最多保留 32 帧，原生展开最多尝试 48 帧，每次观测最多尝试 128 条匹配上传。延迟列表重放复用录制时的栈。根据 `caller_frames_state` 和 `caller_unwind` 检查结果。模块无法解析的帧保留顺序，模块和 RVA 为空。`partial` 标记解析缺口或达到帧上限，`event_limit` 表示超出上传数上限，`unwind_empty` 和 `no_external_frames` 表示当前事件缺栈。`captured` 表示已保存展开返回的外部帧。原生栈展开、内联优化和跨线程提交仍可能让上层装配调用缺席。调用栈和 CPU 字节采样可以独立启用。

在 APMI 六部件和编组实机样本中，脸眼 CS `3b4f1b1749cd3030` 与身体头发 CS `09d91b2eee7e232f` 的相关上传都返回 `UnityPlayer.dll+0x93DD2A`。本机 UnityPlayer 2022.3.62.9394352 的 `0x93DD24` 是 `call qword ptr [rax + 0x180]`，对应 `ID3D11DeviceContext::UpdateSubresource`。x64 unwind 关联的函数入口为 `0x93DB50`。这一共同帧能定位上传包装层。角色详情、大世界和编组是否经过同一个外观装配方法，需要比较这层以上的证据。

### 获取 Unity 侧骨骼身份

D3D11 的 shader、view、缓冲字节和调用方模块只覆盖提交边界。统一骨骼 ID、Transform 父子关系、bind pose 以及矩阵压缩前的槽映射需要从 Unity 项目或引擎构建取证。`dx11_resource_trace_status.unity_bone_identity` 会标记这个缺口。

有 Unity 2021.3 或更新版本的项目时，将仓库中的 `scripts/unity/ProjectBunnySkinningEvidence.cs` 加入其脚本目录。在编辑器用 **Tools → ProjectBunny → Export loaded skinning renderers**，或在开发构建的主线程调用 `ExportLoadedRenderers(path)`。它自动枚举所有已加载场景中的 `SkinnedMeshRenderer`，包括 inactive 渲染器和各级 LOD。导出的 `meshLocalSlots` 提供 `bones[i]` 指向的 Transform 和 `bindposes[i]`。同一快照的 `hierarchy` 可按 Transform instance ID 追父节点，`rigRootInstanceId` 标记该渲染器的骨架锚点。编辑器中有来源时，Prefab 对象和 Mesh 会记录资产 GUID 与本地 file ID。运行时实例 ID 仅用于同进程对应，层级路径和来源资产可用于跨快照提出匹配候选。

若项目拥有 palette 打包逻辑，在重排或压缩完成且上传之前保留最终槽位对应的 Transform 与原始上传字节。在调用上传的前后各取一次 `Stopwatch.GetTimestamp()`，之后将这两个时间和原数据传给 `AppendPaletteUpload`。JSONL 每条记录包含渲染器、LOD、最终槽表、字节长度和 CRC32C。要直接用 Windows DX11 的 `record_qpc` 对齐异步提交，请使用下文直接读取 QPC 的入队观测。使用 Unity 内建打包且只能访问公开场景 API 时，先导出 mesh-local 槽表。最终 GPU palette 的槽表仍需可插桩的打包入口。

可以在角色切换、LOD 资源实例化完毕或新场景加载后调用导出。用一个最小 Unity 场景验收时，让两个渲染器共用一个 rig，并使用顺序不同的 `bones` 数组和一组独立低模。确认它们可按相同 Transform 身份对齐，槽号和 Mesh 身份仍各自对应。若只能读取 GPU 缓冲，可用同帧唯一矩阵和 blend index 分布提出局部对应。重复矩阵、姿态变化、裁掉的骨骼、不同 bind pose 和独立 rig 资源变体会留下歧义。

#### 关联生产者入队与渲染线程上传

APMI 的大世界与编组样本各包含六个部件。12 条上传都从 `UnityGfxDeviceWorker` 线程 70724 录制并提交。每条原生展开 12 帧，保留的 8 个外部帧逐项一致，末尾进入 Kernel32 和 ntdll，样本均未触及展开或帧数上限。这些栈覆盖了图形命令的消费线程。要确认是谁创建或入队这条命令，需在生产者边界另行记录。

在拥有的 Unity 项目或开发构建中，对选中的 palette 调用 `CapturePaletteEnqueue`。它生成 `enqueueId`，记录外观观测 ID、Renderer、生产者 Windows 线程 ID、托管线程 ID、限量托管栈，以及最终上传区间和 CRC32C。在现有入队调用的前后各调用一次 `PaletteEnqueueTimestamp()`，随后用 `AppendPaletteEnqueue` 写入 JSONL。Windows 下使用与 DX11 一致的原生 QPC，并记录与 MCP 一致的进程实例 ID。托管栈会受 IL2CPP 构建设置影响。记录的是调用该采集入口的线程，需把入口放到实际调用排队 API 的位置。[Unity IL2CPP 托管栈说明](https://docs.unity3d.com/2022.3/Documentation/Manual/IL2CPP-managed-stack-traces.html)

- 应用拥有生产和消费两端时，可把 `enqueueId` 留在命令的诊断元数据中。消费端在实际图形 API 上传处记录相同 ID、线程和 QPC，可据此进行一对一确认。上传内容保持原样。
- 对应用自己录制的 Unity `CommandBuffer`，可用 `IssuePluginEventAndData` 将带 ID 的渲染回调与 `SetBufferData` 放在同一命令缓冲，实验测量消费端的标记区间。回调数据须存活到执行完成。只有实测确认 DX11 上传处于同一消费线程和标记区间内，才能用该区间缩小匹配。回调携带的是自身标记，Unity 公开 API 没有提供把它自动附到内建蒙皮命令的入口。[IssuePluginEventAndData](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Rendering.CommandBuffer.IssuePluginEventAndData.html) · [SetBufferData](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Rendering.CommandBuffer.SetBufferData.html)
- APMI 的内建蒙皮路径要取得真实的队列关联 ID，需有可插桩的 Unity 图形命令生产和消费边界，或由拥有者提供同构建的引擎诊断。当前实机材料提供了消费端上传的准确时间、区间和哈希，可在取得生产者记录后用于配对。

可用 `scripts/unity/match_palette_uploads.py` 对照生产者 JSONL 与导出的 DX11 JSON。后者应包含 `target_id`、`qpc_frequency` 和由 `dx11_resource_trace_event` 返回的 `events` 数组。传入开发构建实测的队列延迟上界，脚本用进程、原生 QPC、区间、字节数和 CRC32C 找候选。一个候选仍保留 `candidate` 状态。重复指纹或同一上传可归给多个生产者时报告 `ambiguous`。若拥有两端的项目在实际上传处记录了 ID，可把它作为同一消费者事件的 `producer_enqueue_id`，再核对 `matched_by_id`。重新打包、拆分或没有可读区间的写入需要对应的分段记录。

~~~powershell
python scripts/unity/match_palette_uploads.py producer.jsonl dx11-uploads.json --window-ms 30
~~~

这里的 30 毫秒是命令用法示例。窗口之外没有命中时，检查队列延迟、采集范围和数据重排，再解释结果。

在拥有消费端的构建中，也可以通过 `--upload-windows uploads.jsonl` 自动关联 ID，无需改写 MCP 导出事件。每条 JSONL 记录的 `kind` 为 `dx11_upload_call`，字段为 `enqueueId`、`targetId`、`timestampClock: "windows_qpc"`、`timestampFrequency`、`nativeThreadId`、`beforeUpload` 和 `afterUpload`。时间应紧贴同一线程上的一次实际 DX11 调用。脚本拒绝覆盖多个调用或给同一次提交分配不同 ID 的窗口，再交叉核对上传区间和 CRC32C。通用的渲染回调区间继续用作候选线索。

#### APMI 的 native palette 入队点

本机 UnityPlayer 2022.3.62.9394352 已从 12 条实机消费栈反查出统一的队列命令 `0x274B`。以下为同一二进制内核对的 RVA，可用 `scripts/unity/verify_apmi_palette_queue.py` 在当前 DLL 和深栈对照 JSON 上复核。验证器先核对 DLL 的 SHA256，再检查指令、分发表、虚表和已有实机栈。

| 边界 | 已核对的证据 |
| --- | --- |
| 上游准备 | `0x54E66D` 和 `0x54F047` 调用 `0x54D230`，后者在 `0x54D2C0` 调用 `0x54D040`。该函数按每个 64 字节的 pose 准备缓冲，并引用 `Failed to create compute skin pose buffer!` |
| 生产者 | `0x54D208` 调用图形设备虚表槽 `+0x3A8`，入队实现为 `0xA129F0`。`0xA12A6A` 写命令值，`0xA12AC7`、`0xA12B26` 写两个对齐的引用，`0xA12B40` 发布写进度 |
| 消费者 | worker 在 `0x1112744` 读命令，分发表将 `0x274B` 送到 `0x111E08F`，由 `0x111E163` 调用后端 `0x740A80` |
| DX11 上传 | `0x740A80` 将 pose 数乘以 64，转入 `0x93DB50`，在 `0x93DD24` 调用 `UpdateSubresource`。已有深栈的返回地址依次覆盖两层后端调用和 worker 回路 |

下一次生产者采集可直接以上表的写命令、发布进度和读命令为观测边界。建议在同一运行实例内记录队列标识、逻辑发布序号、命令、两个引用、线程、QPC 和调用栈，消费时沿同一个队列、序号继续关联到 DX11 `record_qpc`。若只能观察循环缓冲的游标，先同时核对队列身份和绕回次数，再尝试对齐；单独的游标会复用。两个引用和 CRC32C 可用来交叉验证。生产者线程与队列实例是否在实际运行中按这一关系配对，仍需两端记录共同验证。

#### 一次采集一个 APMI 场景的生产者证据

新版 DLL 的 `dx11_status.features` 包含 `apmi_palette_producer` 和 `resource_trace_ib_groups`。将 APMI 停在要核对的场景，再运行下面对应的一行。将 `12345` 替换为 `dx11_discover` 返回的新 PID。每条命令在同一窗口内查询该场景的六个已知背靠 IB，并输出各自的 CS-t2、CPU 上传及生产者栈证据。

~~~powershell
python scripts/unity/capture_apmi_palette_producer.py --pid 12345 --scene details --output details-producer.json
python scripts/unity/capture_apmi_palette_producer.py --pid 12345 --scene world --output world-producer.json
python scripts/unity/capture_apmi_palette_producer.py --pid 12345 --scene team --output team-producer.json
~~~

详情和大世界预设来自六部件样本，编组使用实测的低模 IB。若换装或版本变化导致 IB 不同，先从当前场景确认实际 IB，再重复传入 `--ib <hash>` 覆盖该场景的列表。`missing_ib_hashes` 表示当前窗口缺少该绘制。`unconfirmed_producer_ib_hashes` 表示已找到绘制但生产者证据尚未确认。每个场景可先用默认两帧，若 `dropped` 或 `unity_producer_counts.omitted` 非零，可用 `--frames 1` 缩短窗口。

原生采集默认关闭。手动使用 `dx11_resource_trace` 时用 `ib_hashes` 选择一组 IB，传 `producer_frames: 24` 启用生产者栈。DLL 只在 x64 APMI 进程内、UnityPlayer 文件 SHA256 和加载后指令都匹配时装入观测 detour。原函数照常执行，采集仅读取队列元数据与调用栈。一次最多保留 2048 条生产者记录。采集结束后进入透传。同版本进程中后续采集复用已经安装的 detour。

用上传事件的 `unity_producer` 判读结果。`queue_position_and_references` 表示同一队列逻辑位置、两个引用和最终 D3D11 源地址及字节数一致。`synchronous_call` 表示同线程直接调用链也通过上传参数核对。`references_candidate` 用于缺少队列位置而只命中引用的候选。`ambiguous_queue_evidence`、`producer_not_observed` 和 `backend_upload_arguments_differ` 分别标出歧义、窗口缺失和后端上传参数差异。比较三个场景时重点看已确认事件的 `producer_thread`、`producer_qpc` 与 `frames`，再用 Unity 侧外观根和装配记录核对这些路径是否汇合。

这条路径定位到 compute skin pose buffer 的准备和提交。它可用于追问每个渲染器的 palette 来自哪里。整套外观的入口仍用下文的外观根与装配完成事件核对。与当前 DLL 的 CodeView 标识对应的公开 Unity PDB 查询返回 404，当前结果按已核对的 RVA 表示。磁盘 IL2CPP 元数据使用自定义文件头，托管候选方法仍以拥有者的运行时枚举或匹配构建符号为准。

#### 核对角色外观装配入口

1. 在可插桩的 Unity 项目或开发构建中，调用 `ExportCandidateMethods(path, assemblyName, terms)`。指定已加载的项目程序集和角色、外观、渲染器等名称片段。它只读枚举保留的类型和方法签名，最多输出 256 个候选，并标出类型缺失或截断。名称匹配只作为候选，场景资源或程序集被裁剪时需要补足构建侧的元数据。
2. 在一个真正观察到的装配完成位置调用 `AppendAppearanceObservation`。传入程序集、类型和完整方法签名、唯一观测 ID、场景标签、外观根对象及装配前后时间。输出包含根对象下的蒙皮和静态 Mesh 渲染器、共享材料、LOD、Animator、Avatar、根骨与层级。已有的 `AppendPaletteUpload` 可以附上同一观测 ID，给最终槽表和上传内容建立关联。
3. 每个场景从外观实例创建前开启 DX11 观测。外观装配记录通过 `assemblyObservationId` 关联生产者提交，生产者记录再按上文与消费者核对。用最早确认匹配的 `submit_qpc` 标记这次窗口中观察到的首次 D3D11 提交。组装完成与实际消费使用各自的观测事件，可以区分场景包装器和后续渲染任务。
4. 用角色详情、大世界和编组各自的装配记录确认候选是否覆盖脸眼、身体和头发的渲染器集合。三种场景都命中同一程序集、类型和方法签名，且它确实产出这些部件所共用的外观根，才足以确认统一入口。额外的场景包装器、不同 LOD 或资源变体可与共同装配方法一起记录。

已在本机 APMI `GameAssembly.dll` 的 PE 导出表核对域、程序集、image/class 和方法枚举入口，包括 `il2cpp_domain_get_assemblies`、`il2cpp_image_get_class`、`il2cpp_class_get_methods`、`il2cpp_method_get_name`。这些入口可以在已初始化的 IL2CPP 环境中提供保留的元数据。当前 DLL 的导出表未发现 `il2cpp_method_get_pointer`，方法列表本身无法把任意 GameAssembly RVA 可靠地还原为托管方法。需要同构建生成的符号或地址映射，或在拥有的 Unity 项目中记录实际装配调用。现有 APMI 运行证据可以验证 DX11 上传链，Unity 项目内的候选枚举和三场景装配关联仍待实测。

