---
name: projectbunny-dx11-mcp
description: 使用内置的 ProjectBunny DX11 MCP 桥连接 ZZZ 等 DX11 游戏，查询狩猎与性能、调用快捷键、按 hash 或槽位读取 draw 和缓冲区、获取模组资源与 DXBC、读取 F8 产物，以及从启动到卡住或闪退持续采集进程内日志。
---

# ProjectBunny DX11 MCP

使用 [工具和实操手册](references/tools.md) 查当前接口、参数和分步调用。优先使用已连接的 ProjectBunny MCP 服务。工具未挂载时，用 [命令行客户端](scripts/dx11.py) 调同一个 stdio 桥，延续当前聊天完成操作。

## 运行条件与入口

- 完整解压技能目录后，可从任意位置运行 `scripts/dx11.py`。客户端按自身位置加载 `scripts/runtime/` 中的桥和监控模块。运行需要 Windows、64 位 Python 3.9+ 和加载了兼容的 ProjectBunny DX11 MCP DLL 的目标程序。
- ZZZ 默认进程名 `ZenlessZoneZero.exe`。游戏和加载器位置以用户环境为准，每次用 `dx11_discover` 重新发现 PID。要在 Codex 中用技能名自动发现，可将整个目录放入 Codex 的 skills 目录。
- 定点抓取、按键和性能查询需要支持 MCP 的 DLL 已加载、`[System] mcp_enabled = 1`，且 Present 能推进。先查 `dx11_discover` 的 `targets` 和 `dx11_status`。多进程时，每次 Live 请求传完整 `target_id` 或 PID，继续读取同一抓取或性能快照时沿用该目标。同一桥按进程分开连接和调度。验证修复后的 Live 功能时检查 `features` 中的 `profiling_chunks`、`indexed_range` 和 `custom_resource_errors`。
- 启动监控需要支持监控的 DLL 和同一 Windows 会话中的桥。监控独立于 `mcp_enabled`、磁盘日志和渲染控制端点，因此启动前等待时可直接用 `dx11_monitor_start`。同一监控会话的 start、poll 和 stop 使用同一个桥进程。

## 单次调用与持续会话

把下面的 `$dx` 设为解压目录下的 `scripts/dx11.py`，然后调用工具。

~~~powershell
$dx = 'C:/path/to/projectbunny-dx11-mcp/scripts/dx11.py'
python $dx list
python $dx list --tool dx11_capture
python $dx call dx11_discover
'{"kind":"ib"}' | python $dx call dx11_hunting -
~~~

`call` 每次启动短命的桥。长时间监控用 MCP 原会话，或运行客户端的 `watch`。`session` 可以从 stdin 接收多条一行一条的 `{"tool":"dx11_status","arguments":{}}` 请求并保持同一个桥。注册 stdio MCP 服务时用 `python <技能目录>/scripts/dx11.py stdio`。开发时可用 `--workspace` 选用一个源码检出里的桥。用 `--pid` 指定默认 Live PID，用 `--output-dir` 指定定点抓取文件的保存目录。

## 选取工作流

- **按键或狩猎时**，用 `dx11_hotkeys` 查 action ID，调用 `dx11_hotkey`，再用 `dx11_hunting` 验证当前选择。现有配置的 `hunting=2` 可通过 `Hunting.toggle_hunting` 切换。Ctrl+Alt+F10 清除持久设置，只有用户授权这项操作后才传 `confirm_wipe:true`。
- **定点抓取时**，用 `dx11_capture` 按 hash、draw、stage、slot、来源或资源 ID 缩小范围。只抓直接索引绘制使用的字节时传 `kind:"ib", indexed_range:true`。与 F8 比对时，按结果的 `index_range.offset` 和 `index_range.length` 截取同 hash 的 `.buf`。等 `ready` 后分块读或保存，再发起另一项捕获。自定义 buffer 和 shader 的字节码也共用捕获槽。
- **定位 mod 时**，核对用户提供的 INI 节、shader 和绑定。自定义缓冲区优先按 `dx11_custom_buffers` 返回的名字读取，失败时用 MCP 的 `structuredContent.code` 或命令行客户端显示的错误码区分原因。在 draw 或 dispatch 时读取数据可用 `source:"mod"` 和实际槽位。DXBC 通过 shader catalog ID 提取。
- **调查加载卡住或闪退时**，提前启动监控，让桥持续收取内存事件。下次轮询使用此次返回的 `next_seq`。发现 `no_progress` 时记录最后阶段与帧号，退出时读取保留事件和可用的退出码。保持监控直到用户指定的条件，结束时关闭自己创建的监控。渲染控制端点缺席时也继续观察已启动的独立监控。
- **重连监控时**，在新的桥里启动监控并使用新会话的游标。比较 `pid` 和 `process_start` 确认是否为同一次游戏运行，用 `identity_source` 核对恢复途径。继续读取仍保留的事件。
- **读取性能时**，用 `dx11_profiling` 读 Ctrl+F9 面板。大面板先用 `length` 建立快照，再靠同一个 `snapshot_id` 和 UTF-8 字节 `next_offset` 分块读完。按需用 `dx11_log_tail` 读取已有文件日志。延迟上下文、纹理字节和完整 API 记录按现有 F8 配置采集，再分页列文件、分块读取。

状态、日志、字节都以实际工具返回为准。日志里的错误码或停滞点可用于定位，仍需验证其是否造成用户所见故障。按用户授权范围触发动作，部署 DLL、改配置和启动或结束游戏属于另外的实际操作。
