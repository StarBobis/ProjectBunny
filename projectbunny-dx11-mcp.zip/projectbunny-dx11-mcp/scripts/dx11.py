"""Call the ProjectBunny DX11 MCP stdio bridge from a shell."""

import argparse
from contextlib import contextmanager, nullcontext
import ctypes
import json
import math
from pathlib import Path
import subprocess
import sys
import time


DEFAULT_WORKSPACE = Path("E:/代码/ProjectBunny-main")
DEFAULT_EXE = "ZenlessZoneZero.exe"


class Mcp:
    def __init__(self, process):
        self.process = process
        self.request_id = 0

    def send(self, message):
        self.process.stdin.write(json.dumps({"jsonrpc": "2.0", **message}) + "\n")
        self.process.stdin.flush()

    def request(self, method, **params):
        self.request_id += 1
        self.send({"id": self.request_id, "method": method, "params": params})
        while line := self.process.stdout.readline():
            reply = json.loads(line)
            if "id" not in reply:  # Notifications can arrive before the result.
                continue
            if reply["id"] != self.request_id:
                raise RuntimeError(f"Unexpected MCP response id {reply['id']!r}")
            if "error" in reply:
                raise RuntimeError(reply["error"]["message"])
            return reply["result"]
        raise RuntimeError(f"DX11 MCP bridge closed during {method}")

    def tool(self, name, arguments=None):
        if arguments is None:
            arguments = {}
        if not isinstance(arguments, dict):
            raise ValueError("Tool arguments must be a JSON object")
        result = self.request("tools/call", name=name, arguments=arguments)
        if result.get("isError"):
            message = "\n".join(item["text"] for item in result["content"] if item.get("type") == "text")
            raise RuntimeError(message or "DX11 tool returned an error")
        return json.loads(result["content"][0]["text"])


@contextmanager
def open_bridge(args):
    root = args.workspace.resolve()
    bridge = root / "scripts" / "dx11-mcp.py"
    if not bridge.is_file():
        raise FileNotFoundError(f"DX11 bridge not found at {bridge}. Pass --workspace with the repository path.")
    command = [sys.executable, str(bridge)]
    if args.pid is not None:
        command += ["--pid", str(args.pid)]
    if args.output_dir:
        command += ["--output-dir", str(args.output_dir.resolve())]
    process = subprocess.Popen(command, cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE, encoding="utf-8")
    try:
        client = Mcp(process)
        client.request("initialize", protocolVersion="2025-06-18",
                       capabilities={}, clientInfo={"name": "projectbunny-dx11-skill", "version": "1.0"})
        client.send({"method": "notifications/initialized"})
        yield client
    finally:
        process.stdin.close()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        process.stdout.close()


def emit(value, record=None):
    line = json.dumps(value, ensure_ascii=True)
    if record is not None:
        record.write(line + "\n")
        record.flush()
    print(line, flush=True)


def session(client):
    """Read one tool call per stdin line while the same bridge remains alive."""
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            request = json.loads(line)
            if not isinstance(request, dict) or not isinstance(request.get("tool"), str):
                raise ValueError('Expected {"tool":"dx11_...","arguments":{}}')
            emit({"ok": True, "result": client.tool(request["tool"], request.get("arguments", {}))})
        except (RuntimeError, ValueError, OSError, KeyError) as error:
            emit({"ok": False, "error": str(error)})


def watch(client, args, record):
    kernel = ctypes.WinDLL("kernel32")
    tick = kernel.GetTickCount64
    tick.argtypes = ()
    tick.restype = ctypes.c_uint64
    start_tick = tick()
    started = client.tool("dx11_monitor_start", {
        "target_exe": args.exe, "level": args.level, "stall_ms": args.stall_ms,
    })
    emit({"event": "monitor_ready", **started}, record)
    cursor = started["next_seq"]
    deadline = time.monotonic() + args.seconds if args.seconds is not None else math.inf
    observed = set()
    prior_status = []
    prior_dropped = 0
    reached = False
    while time.monotonic() < deadline:
        remaining = deadline - time.monotonic()
        wait_ms = 1000 if remaining >= 1 else max(0, int(remaining * 1000))
        poll = {"after_seq": cursor, "limit": 256, "wait_ms": wait_ms}
        if args.pid is not None:
            poll["pid"] = args.pid
        current = client.tool("dx11_monitor_poll", poll)
        if current["monitor_error"]:
            raise RuntimeError(current["monitor_error"])
        cursor = current["next_seq"]
        for event in current["events"]:
            if event["tick_ms"] < start_tick:
                continue
            identity = (event["pid"], event["process_start"])
            if event["kind"] != "process_exit":
                observed.add(identity)
            if identity in observed:
                emit({"event": "diagnostic", **event}, record)
        statuses = [status for status in current["sessions"] if
                    (status["pid"], status["process_start"]) in observed]
        fingerprint = [(s["pid"], s["process_start"], s["state"], s["phase"], s["exit_code"]) for s in statuses]
        if fingerprint != prior_status or current["transport_dropped"] != prior_dropped or current["history_lost"]:
            emit({"event": "monitor_status", "sessions": statuses, "next_seq": cursor,
                  "transport_dropped": current["transport_dropped"], "history_lost": current["history_lost"]}, record)
            prior_status = fingerprint
            prior_dropped = current["transport_dropped"]
        if args.until and any(status["state"] == args.until for status in statuses):
            reached = True
            break
    stopped = client.tool("dx11_monitor_stop")
    emit({"event": "monitor_finished", "reason": "condition_reached" if reached else "time_elapsed",
          "condition_met": reached if args.until else None, **stopped}, record)
    return 3 if args.until and not reached else 0


def positive_seconds(value):
    seconds = float(value)
    if not math.isfinite(seconds) or seconds <= 0:
        raise argparse.ArgumentTypeError("seconds must be positive and finite")
    return seconds


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--pid", type=int, help="Default live PID or watch filter")
    parser.add_argument("--output-dir", type=Path, help="DX11 MCP capture output directory")
    subparsers = parser.add_subparsers(dest="command", required=True)
    tools = subparsers.add_parser("list", help="List tools or show one tool schema")
    tools.add_argument("--tool", help="Full tool name, such as dx11_capture")
    call = subparsers.add_parser("call", help="Invoke one tool")
    call.add_argument("tool")
    call.add_argument("json", nargs="?", default="{}", help="JSON arguments or '-' to read stdin")
    subparsers.add_parser("session", help="Keep one bridge open and read one JSON tool request per stdin line")
    monitor = subparsers.add_parser("watch", help="Continuously receive diagnostics in the same bridge")
    monitor.add_argument("--exe", default=DEFAULT_EXE)
    monitor.add_argument("--level", choices=("warning", "info", "debug"), default="warning")
    monitor.add_argument("--stall-ms", type=int, default=5000)
    monitor.add_argument("--seconds", type=positive_seconds, help="Maximum observation time")
    monitor.add_argument("--until", choices=("presenting", "no_progress", "exited"))
    monitor.add_argument("--record", type=Path, help="Write NDJSON to a new file")
    args = parser.parse_args(argv)

    sys.stdin.reconfigure(encoding="utf-8")
    try:
        with open_bridge(args) as client:
            if args.command == "list":
                available = client.request("tools/list")["tools"]
                if args.tool:
                    schema = next((tool for tool in available if tool["name"] == args.tool), None)
                    if schema is None:
                        raise ValueError(f"Unknown tool {args.tool}")
                    emit(schema)
                else:
                    emit({"tools": [tool["name"] for tool in available]})
            elif args.command == "call":
                arguments = json.loads(sys.stdin.read() if args.json == "-" else args.json)
                emit(client.tool(args.tool, arguments))
            elif args.command == "session":
                session(client)
            else:
                with (args.record.open("x", encoding="utf-8") if args.record else nullcontext()) as output:
                    return watch(client, args, output)
    except KeyboardInterrupt:
        return 130
    except (RuntimeError, ValueError, OSError, KeyError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
